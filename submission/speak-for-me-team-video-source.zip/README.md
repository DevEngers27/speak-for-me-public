# Speak for Me — canonical team product film

177.0 seconds, 1920 × 1080, 30 fps. Rendered with Remotion 4.0.538. Identity architecture and narration updated to direct Google identity on user request.

## Reproduce

Use Node 24 and `npm ci`, then:

```
npx remotion render src/index.ts SpeakForMe raw.mp4 --codec=h264 --crf=18 --pixel-format=yuv420p --concurrency=2
ffmpeg -i raw.mp4 -c:v copy -af loudnorm=I=-16:TP=-1.5:LRA=11 -c:a aac -b:a 192k -ar 48000 -movflags +faststart speak-for-me-team-demo.mp4
```

Use `--browser-executable=/absolute/path/to/chrome-headless-shell` if the renderer's default browser is incompatible. The reviewed render used Chromium headless shell build1248 on macOS arm64.

## Provenance

The three UI images render the actual canonical React RoomWorkbench, DecisionScreen and ResultsScreen from DevEngers27/speak-for-me with role-projected synthetic fixtures. They are illustrative viewport excerpts, not a live account recording. The surrounding graphics explain the canonical workflow. English narration is synthetic en-US-AriaNeural; WAV assets and caption timing are included for deterministic reuse. No credentials or customer data are included.

The measured backend separately made seven real Claude calls. It required an explicit Customer choice after agent disagreement, then three fresh human approvals completed execution. The video does not claim autonomous agreement, real three-account Google browser acceptance, customer usage, payments or signatures.

The cap4700 variation also passed a separate deployed deterministic precheck with synthetic admin identities and explicit Finance end-run; no first model attempt was started. The final human vote executes atomically; there is no additional Execute step.
