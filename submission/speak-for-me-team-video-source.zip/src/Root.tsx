import React from 'react';
import {Composition} from 'remotion';
import {ProductFilm} from './Film';
import data from './story.json';
export const RemotionRoot=()=> <Composition id="SpeakForMe" component={ProductFilm} durationInFrames={data.duration} fps={30} width={1920} height={1080}/>;
