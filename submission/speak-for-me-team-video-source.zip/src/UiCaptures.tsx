import React from 'react';
import {AbsoluteFill} from 'remotion';
import {RoomWorkbench} from '../../../team-release/src/components/room/RoomWorkbench';
import {BriefScreen,DecisionScreen,ResultsScreen} from '../../../team-release/src/components/room/RoomSections';
import {buildRoomView,buildExecution,buildBriefQuery,buildCatalogQuery} from '../../../team-release/tests/ui/fixtures';
import '../../../team-release/src/app/globals.css';
export function UiCapture({screen='workbench'}:{screen?:string}) {
 const role=screen==='provider'?'provider':screen==='brief'?'customer':'finance';
 const phase=screen==='results'?'S11':screen==='proposal'?'S5':'S7';
 const view=buildRoomView(role,phase);
 return <AbsoluteFill style={{background:'#eef5f2',padding:30,overflow:'hidden',fontFamily:'Arial, sans-serif'}}><div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 8px 22px',color:'#315f59'}}><strong style={{fontSize:25}}>◌ Speak for Me</strong><span style={{fontSize:17}}>ILLUSTRATIVE PRODUCT STATE · {role.toUpperCase()}</span></div><div style={{width:'100%',overflow:'hidden'}}>{screen==='brief'?<BriefScreen view={view} brief={buildBriefQuery(role,phase)} catalog={buildCatalogQuery()}/>:screen==='proposal'?<DecisionScreen view={view} version={1}/>:screen==='results'?<ResultsScreen view={view} execution={buildExecution(role,'S11')}/>:<RoomWorkbench view={view}/>}</div></AbsoluteFill>;
}
