export const usePathname=()=>'/rooms/illustration';
export const useRouter=()=>({push:()=>{},replace:()=>{}});
