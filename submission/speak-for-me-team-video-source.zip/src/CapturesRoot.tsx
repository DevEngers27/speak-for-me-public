import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {UiCapture} from './UiCaptures';
const Root=()=> <>{['workbench','provider','brief','proposal','results'].map(screen=><Composition key={screen} id={screen} component={UiCapture} defaultProps={{screen}} durationInFrames={30} fps={30} width={1600} height={1100}/>)}</>;
registerRoot(Root);
