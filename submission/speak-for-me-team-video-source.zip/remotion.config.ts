import {Config} from '@remotion/cli/config';
Config.setRspack(false);
Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);
