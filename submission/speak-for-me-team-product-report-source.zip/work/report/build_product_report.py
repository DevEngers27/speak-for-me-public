from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/speak-for-me-team-product-report.pdf'
ASSETS=ROOT/'work/team-video/film/public'
FONT=Path('/System/Library/Fonts/Supplemental')
for name,file in [('Body','Arial.ttf'),('Bold','Arial Bold.ttf'),('Italic','Arial Italic.ttf')]: pdfmetrics.registerFont(TTFont(name,str(FONT/file)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Italic',boldItalic='Bold')
W,H=842,595
INK='#173E3C'; TEAL='#165F59'; PALE='#EFF6F1'; MUTED='#536D67'; LINE='#D4E2DB'; AMBER='#F2CE70'
c=canvas.Canvas(str(OUT),pagesize=(W,H));c.setTitle('Speak for Me | Product & Evidence Report');c.setAuthor('Speak for Me project team');c.setSubject('Canonical three-role product and qualified release evidence, October 25, 2026')

def box(x,y,w,h,color,r=9,stroke=None):
 c.setFillColor(HexColor(color));c.setStrokeColor(HexColor(stroke or color));c.roundRect(x,y,w,h,r,fill=1,stroke=bool(stroke))
def text(txt,x,y,w,size=11,color=INK,bold=False,leading=None):
 p=Paragraph(txt,ParagraphStyle('p',fontName='Bold' if bold else 'Body',fontSize=size,leading=leading or size*1.4,textColor=HexColor(color),spaceAfter=0))
 aw,ah=p.wrap(w,900);p.drawOn(c,x,y-ah);return y-ah

def title(kicker,heading,sub=None):
 text(kicker.upper(),44,549,750,9,TEAL,True,12)
 text(heading,44,521,750,27,INK,True,32)
 if sub: text(sub,44,480,744,11,MUTED)
def footer(num):
 c.setStrokeColor(HexColor(LINE));c.line(44,37,798,37)
 text('SPEAK FOR ME  /  PRODUCT & EVIDENCE REPORT',44,26,500,7.5,MUTED,True)
 text('25 OCT 2026',660,26,90,7.5,MUTED)
 text(f'{num:02d} / 07',763,26,40,7.5,MUTED)
def page(num): footer(num);c.showPage()
def label(txt,x,y,w=180,color=TEAL): text(txt.upper(),x,y,w,9,color,True,12)
def screenshot(name,x,y,w):
 h=w*1100/1600;c.drawImage(str(ASSETS/name),x,y,width=w,height=h,mask='auto');return h

def caption(txt,x,y,w): text(txt,x,y,w,8,MUTED,False,11)
def line(x1,y1,x2,y2):c.setStrokeColor(HexColor(LINE));c.setLineWidth(1);c.line(x1,y1,x2,y2)

# 1 - Product thesis
box(0,0,W,H,PALE,0)
text('Speak for Me',44,552,500,17,TEAL,True)
label('CalHacks product report',617,548,180)
box(44,220,754,271,TEAL,14)
text('Find the terms.<br/>Keep the final say.',70,465,470,40,'#FFFFFF',True,44)
text('A shared negotiation workspace for Customer, Provider, and Finance. Agents explore supported terms. People decide what becomes an agreement.',73,351,465,13,'#DCEEE6',False,19)
box(588,263,183,179,'#F5D581',10)
label('The product promise',606,420,150,INK)
text('Private constraints.<br/>Visible trade-offs.<br/>Exact approvals.',606,390,146,15.5,INK,True,24)
text('No external payment or binding signature is sent.',606,298,143,9,INK,False,13)
for x,num,head,body in [(44,'01','Brief','Confirm constraints and choose disclosures.'),(239,'02','Negotiate','Agents work from confirmed catalog sources.'),(434,'03','Decide','Review the exact proposal and versions.'),(629,'04','Record','Final approval records one internal outcome.')]:
 label(num,x,193,170);text(head,x,172,165,14,INK,True);text(body,x,147,166,10,MUTED)
caption('Canonical release: DevEngers27/speak-for-me main baseline + PR 101 + release improvements. Delivery branch: final_product.',44,72,750)
page(1)

# 2 - Architecture and privacy
box(0,0,W,H,'#FFFFFF',0)
title('Design & architecture','Three agents. One controlled decision.','Google sign-in runs through Clerk. Convex verifies sessions and projects each role\'s data.')
for x,head,body in [(44,'Customer','Required scope, preferred items and delivery deadline.'),(301,'Provider','Confirmed catalog prices, lead times and delivery tasks.'),(558,'Finance','Budget cap, existing commitments and final spending authority.')]:
 box(x,365,240,83,PALE,8);text(head,x+14,433,212,13,TEAL,True);text(body,x+14,408,212,10,MUTED)
for x,w,head,body in [(44,170,'Google via Clerk','Google sign-in + Clerk session'),(235,170,'Convex state','Verified identity + permissioned access'),(426,170,'Bounded agents','Role-scoped Claude proposals'),(617,181,'Deterministic rules','Source checks, approvals, atomic records')]:
 box(x,274,w,66,'#FAFCFA',7,LINE);text(head,x+10,327,w-20,11,INK,True);text(body,x+10,307,w-20,9,MUTED)
 if x<617:text('>',x+w+6,310,17,13,TEAL,True)
screenshot('provider.png',44,58,286)
label('Provider view',353,249,425)
text('A fit signal, never Finance\'s private budget.',353,225,425,18,INK,True)
text('Provider cannot receive the cap, committed balance, headroom, or private budget-derived checks. Customer sees explicitly disclosed fields. Private notes and agent rationale stay with their principal.',353,171,425,11,MUTED)
text('Every human approval binds immutable terms, a constraints version, and a member. A stale vote cannot authorize new terms.',353,101,425,11,INK,True)
caption('Illustrative React fixture render; not a connected browser capture.',44,55,290)
page(2)

# 3 - Observed live flow
box(0,0,W,H,PALE,0)
title('Observed live recovery','A budget cut changes the agreement.','Real Claude calls on the isolated Convex deployment; synthetic seed identities via admin impersonation.')
steps=[('1','$900 proposal','SSO login $500 + audit export $300 + optional dashboard $100. Customer and Provider approved; Finance had not.'),('2','$5,000 → $4,800 cap','Finance reduced the cap with $4,000 already committed. Constraints became v2; two earlier approvals no longer applied.'),('3','Human choice required','The live run reached rounds_exhausted / needs_input. Autonomous completion stopped. Customer explicitly selected option A, reusing the existing live-model $800 essentials proposal.'),('4','$800 recorded outcome','Three fresh approvals. The final required vote recorded one execution, one ledger commitment, one change order and two tasks.')]
y=442
for n,head,body in steps:
 box(44,y-75,474,75,'#FFFFFF',7)
 box(58,y-34,24,24,TEAL,5);text(n,65,y-14,15,10,'#FFFFFF',True)
 text(head,96,y-11,408,13,INK,True);text(body,96,y-32,400,9.3,MUTED,False,13)
 y-=86
box(540,111,258,331,TEAL,10)
label('Measured live window',559,421,220,'#DCEEE6')
text('7',559,395,218,45,'#FFFFFF',True,49);text('real model calls',559,342,218,12,'#FFFFFF')
text('$0.086849',559,306,218,25,'#F4D77C',True);text('Estimated model cost',559,272,218,10,'#DCEEE6')
text('p50 4.106 s  /  p95 4.448 s',559,238,218,11,'#FFFFFF',True)
text('Deployment-wide window, n = 7. Cost uses the 2026-10-06 price table and is an estimate, not an invoice. This tiny sample is not a performance benchmark.',559,209,218,9,'#DCEEE6',False,13)
caption('Separate $4,700 check: Finance chose end_run; no model turn, execution, commitment or tasks; budget unchanged and zero invariant findings.',44,96,754)
caption('Observed final-approval overlap returned one outcome; the probe reported zero invariant findings and passed projected privacy checks.',44,79,754)
caption('Evidence: 2026-10-25-release-live-smoke.json and 2026-10-25-release-human-recovery.json. The autonomous smoke remains pass:false; the explicit human recovery is pass:true.',44,62,754)
page(3)

# 4 - Workbench
box(0,0,W,H,'#FFFFFF',0)
title('Product surface / workbench','A shared workspace with private boundaries.')
screenshot('workbench.png',44,72,600)
label('Current terms',666,447,125)
text('Proposal and constraint versions stay visible beside the required decision.',666,425,125,10,MUTED)
label('Private context',666,349,125)
text('Your own brief and shared facts remain separate from the common proposal.',666,327,125,10,MUTED)
label('Progress',666,246,125)
text('Run state, waiting, history, and recovery links explain what happens next.',666,224,125,10,MUTED)
label('Readable details',666,139,125)
text('Item titles come only from the viewer\'s projected catalog.',666,117,125,10,MUTED)
caption('ILLUSTRATIVE VIEWPORT EXCERPT: current React workbench rendered with a canonical Finance fixture. These fixture images do not establish browser login or live synchronization.',44,61,750)
page(4)

# 5 - Decision and editors
box(0,0,W,H,PALE,0)
title('Product surface / decision','Consent means these exact terms.')
screenshot('proposal.png',44,72,600)
label('Human authority',666,447,125)
text('Agent suggestions are separate from rule checks and approvals.',666,425,125,10,MUTED)
label('Version binding',666,351,125)
text('Changed constraints invalidate earlier authority. People review and approve again.',666,329,125,10,MUTED)
label('Editors completed',666,251,125)
text('Required scope and wishlist selectors; private notes; catalog task templates; disclosure recipients and withdrawal.',666,229,125,10,MUTED)
label('Save safeguards',666,121,125)
text('Pending locks, draft warnings and reconnect status.',666,99,125,10,MUTED)
caption('ILLUSTRATIVE VIEWPORT EXCERPT: canonical fixture rendered by the actual proposal screen. An offered candidate creates/selects a proposal; it does not count as approval.',44,61,750)
page(5)

# 6 - Recorded result
box(0,0,W,H,'#FFFFFF',0)
title('Product surface / outcome','Final approval records the agreement.')
screenshot('results.png',44,72,600)
label('One outcome',666,447,125)
text('The last required approval atomically records the internal change order, commitment and tasks.',666,425,125,10,MUTED)
label('Observed recovery',666,331,125)
text('Audit log export and SAML SSO. Two Provider tasks, due November 8 in the live recovery probe.',666,309,125,10,MUTED)
label('Follow-up',666,202,125)
text('A separate setup room was created once. Its $4,800 baseline suggestion still required Finance confirmation.',666,180,125,10,MUTED)
label('No money moves',666,87,125)
text('Internal records only.',666,65,125,10,MUTED)
caption('ILLUSTRATIVE PRODUCT STATE: rendered Results fixture. Fixture dates/text can differ from the real probe. The live recovery evidence, rather than this image, establishes the observed result.',44,61,595)
page(6)

# 7 - Evidence boundaries
box(0,0,W,H,PALE,0)
title('Evidence & release boundaries','What is established. What remains open.','Evidence types stay separate: implementation, test fixtures, deployed probes, and real browser authentication.')
rows=[
 ('ESTABLISHED','Connected model + backend','Seven real Claude calls, budget-cut invalidation and explicit human recovery to $800. Final approvals recorded one execution, commitment, change order and two tasks. These probes used synthetic admin identities, not browser login.',64),
 ('LIVE IDENTITY','Google sign-in via Clerk','The public site uses Google sign-in through Clerk, with Convex enforcing room membership and role permissions. One real account opened the inbox, created a Provider room, and saved private notes that remained after reload as confirmed brief v1.',75),
 ('RELEASE CHECKS','Engineering evidence','Released CI on commit 97c1417 passed 2,154 tests with 39 TODO cases retained. Lint, typechecks, builds and artifact checks passed. The authenticated browser workflow was skipped; these engineering checks do not prove a three-member browser journey.',85),
 ('ILLUSTRATIVE','Screenshots + finished video','The 177.0-second, 1080p/30 fps H.264/AAC film is complete; decode, subtitle timings and visuals were reviewed. Its Google identity label refers to Google sign-in via Clerk. React fixture renders are not authenticated browser footage.',64),
 ('OPEN','Public site + final acceptance','The entry site is public; rooms remain authenticated and membership-protected. Three-account acceptance, live synchronization and task completion remain unverified. Eligibility and Devpost submission status require separate confirmation; no submission is established by this report.',75),
]
y=445
for status,head,body,h in rows:
 box(44,y-h,754,h-5,'#FFFFFF',7)
 label(status,58,y-15,108,TEAL if status!='OPEN' else '#865600')
 text(head,182,y-12,193,11,INK,True)
 text(body,382,y-11,399,9.2,MUTED,False,12)
 y-=h
text('Evidence references',44,80,180,10,INK,True)
text('Repository: github.com/DevEngers27/speak-for-me / final_product. Released source baseline: 97c1417.<br/>Evidence: release-{live-smoke,human-recovery,infeasible-smoke,browser-smoke}.json; docs/release/VALIDATION.md.<br/>Public entry: <link href="https://speak-for-me-calhacks.lgc783656618.chatgpt.site" color="#165F59">speak-for-me-calhacks.lgc783656618.chatgpt.site</link>. Google sign-in via Clerk; authenticated room access.',182,80,615,8,MUTED,False,11)
page(7)
c.save()
reader=PdfReader(str(OUT));assert len(reader.pages)==7
for i,p in enumerate(reader.pages): assert len(p.extract_text().strip())>150,(i,'empty')
print(OUT);print('7 pages; text extraction verified')
