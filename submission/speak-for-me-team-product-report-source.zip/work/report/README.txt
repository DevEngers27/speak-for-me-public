Speak for Me - product report source

Rebuild from the extracted archive root:
  mkdir -p outputs
  python3 work/report/build_product_report.py

Dependencies: reportlab, pypdf. The script uses Arial TrueType fonts from
/System/Library/Fonts/Supplemental on macOS. Change FONT in the script to a
locally licensed Arial-compatible font directory on another host.

Render for review:
  pdftoppm -scale-to 1600 -png outputs/speak-for-me-team-product-report.pdf work/report/rendered/page

The released public site uses Google sign-in through Clerk and Convex room
authorization. Its source baseline is 97c1417; released CI passed 2154 tests,
with 39 TODO retained and authenticated browser CI skipped. One real account
was observed signing in, opening the inbox, creating a Provider room and saving
private notes retained after reload. Three-account acceptance remains unverified.

The four screen images and 177.0-second film use canonical illustrative React
fixtures, not authenticated browser footage. Google in the film means Google
identity via Clerk. Model probes use synthetic admin identities: autonomous smoke
is pass:false; explicit human recovery is pass:true. No external payment occurs.
Direct-Google experimental source and pending configuration are not this release.
